<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/nueva-entrada', 'DirectorioController@crearEntrada');
Route::post('/confirmar-eliminacion', 'DirectorioController@confirmarEliminacion');
Route::get('/buscar-entrada', 'DirectorioController@buscarEntrada');
Route::get('/ver-entrada/{id}', 'DirectorioController@verEntrada');
Route::get('/eliminar-entrada/{id}', 'DirectorioController@eliminarEntrada');
Route::post('/guardar-entrada', 'DirectorioController@guardarEntrada');
Route::post('/buscar-entrada', 'DirectorioController@buscarEntrada')->name('buscar-entrada');
Route::get('/agregar-contacto/{id}', 'DirectorioController@agregarContacto');
Route::get('/eliminar-contacto/{entrada}/{contacto}', 'DirectorioController@eliminarContacto');
Route::post('/guardar-contacto/{entrada}', 'DirectorioController@guardarContacto')->name('guardar-contacto');


